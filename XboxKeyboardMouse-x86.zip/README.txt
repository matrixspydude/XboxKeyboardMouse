XboxKeyboardMouse - Portable Version
===================================

ABOUT
-----
This is a portable version of XboxKeyboardMouse. No installation is required.

HOW TO USE
----------
1. Extract the entire ZIP file into a folder named XboxKM on the drive of your choice.
   Example: "Drive Letter":\XboxKM
   Such as: C:\XboxKM or D:\XboxKM

2. Keep all included files together in that folder.

3. Run XboxKeyboardMouse.exe.

IMPORTANT
---------
Do not run the program directly from inside the ZIP file. Extract it first.

This is a modified build of XboxKeyboardMouse with compatibility fixes and updates.
